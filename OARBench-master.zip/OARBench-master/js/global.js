//GLOBAL VAR DECLARATIONS
var graphOpen = false;
var routesOpen = false;
