# OARBench
Benchmark instance generation for arc routing problems based on real-world street network data.

NW.js GIS desktop app that enables arc routing researchers to use OSM data to create test instances for their solvers.
If you just want to use the app, look in the releases for your OS, download the zip, extract it, and double click the OARBench app.
